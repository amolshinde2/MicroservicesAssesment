package com.example.demo;


import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

@Service
public class OrderService implements IOrderService{
	
	@Autowired
	JmsTemplate jmsTemplate ;
	
	
	private static final String MESSAGE_QUEUE = "message_queue";
	private static final String EXPENSIVE_QUEUE = "expensive_queue";
	@Override
	public void createOrder(Order order, HttpSession httpSession) throws Exception {
		if(order.getPrice()<=0)
		{
			throw new Exception("Price should be greater than 0");
		}else {
				
		System.out.println("create service called...");
		

					// Send a message
					System.out.println("Sending a order " + order);
					if(order.getPrice()<10000)
					{
						jmsTemplate.convertAndSend(MESSAGE_QUEUE, order);
					}else {
						jmsTemplate.convertAndSend(EXPENSIVE_QUEUE, order);
					}
					@SuppressWarnings("unchecked")
					List<Order> orders = (List<Order>) httpSession.getAttribute("MY_SESSION_ORDERS");
					if (orders == null) {
						orders = new ArrayList<Order>();
						httpSession.setAttribute("MY_SESSION_ORDERS", orders);
					}
					orders.add(order);
					httpSession.setAttribute("MY_SESSION_ORDERS", orders);		
		
		
		}
	}
	public String updateOrder(Order order){
		return "update successfully";
	}
	@Override
	public String getOrder(HttpSession httpSession) throws Exception {
		StringBuilder ordersInSession = new StringBuilder();
		@SuppressWarnings("unchecked")
		List<Order> orders = (List<Order>) httpSession.getAttribute("MY_SESSION_ORDERS");
		if (orders == null) {
			throw new Exception("There's no order available");
		} else {
			ordersInSession = new StringBuilder();
			for (Order order : orders) {
				
				ordersInSession.append(order.toString());
				ordersInSession.append("  ");
				
			}
		}
		
		return ordersInSession.toString();
	}
}
