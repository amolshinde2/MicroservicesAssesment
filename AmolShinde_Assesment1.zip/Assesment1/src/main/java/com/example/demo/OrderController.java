package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController()
@RequestMapping("/order")
public class OrderController {

	@Autowired  //DI
	IOrderService service; 

	//@PostMapping("/order")
	@PostMapping
	public String createOrder(@RequestBody Order order, HttpServletRequest request) {
		System.out.println(order);

		try {

			service.createOrder(order,request.getSession());

		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
			return e.getMessage();
		}
		return "success";
	}

	//@GetMapping("/order")
	@GetMapping
	public String getOrder(HttpServletRequest request)
	{
		String order;
		try
		{
			order = service.getOrder(request.getSession());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
			return e.getMessage();
		}
		return order;
	}

	//@PutMapping("/order")
	@PutMapping
	public String updateOrder(Order order) {
		service.updateOrder(order);
		return "order updated";
	}
}

