package com.example.demo;

import javax.servlet.http.HttpSession;

public interface IOrderService {
	void createOrder(Order order, HttpSession httpSession) throws Exception;
	String updateOrder(Order order);
	String getOrder(HttpSession httpSession) throws Exception;
}
