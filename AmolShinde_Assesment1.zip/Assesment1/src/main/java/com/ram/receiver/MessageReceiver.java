package com.ram.receiver;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.example.demo.Order;


@Component
public class MessageReceiver
{
	private static final String NORMAL_QUEUE = "normal_queue";
	private static final String EXPENSIVE_QUEUE = "expensive_queue";
	
	@JmsListener(destination = NORMAL_QUEUE)
	public void receiveMessage(Order order)
	{
		System.out.println("Received " + order);
	}
	
	@JmsListener(destination = EXPENSIVE_QUEUE)
	public void receiveExpensiveMessage(Order order)
	{
		System.out.println("Received " + order);
	}
}
